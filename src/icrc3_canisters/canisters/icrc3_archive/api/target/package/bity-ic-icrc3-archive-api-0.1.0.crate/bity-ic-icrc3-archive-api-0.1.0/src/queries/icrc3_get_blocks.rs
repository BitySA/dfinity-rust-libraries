use icrc_ledger_types::icrc3::blocks::{GetBlocksRequest, GetBlocksResult};

pub type Args = Vec<GetBlocksRequest>;
pub type Response = GetBlocksResult;

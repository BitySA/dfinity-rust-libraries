use bity_ic_types::BuildVersion;

pub type Args = ();
pub type Response = BuildVersion;

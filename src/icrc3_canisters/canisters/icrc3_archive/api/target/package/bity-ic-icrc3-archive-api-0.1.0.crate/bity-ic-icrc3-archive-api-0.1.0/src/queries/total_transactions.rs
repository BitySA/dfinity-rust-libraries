pub type Args = ();
pub type Response = usize;

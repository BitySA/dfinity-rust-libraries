pub mod get_version;
pub mod icrc3_get_blocks;
pub mod remaining_capacity;
pub mod total_transactions;
